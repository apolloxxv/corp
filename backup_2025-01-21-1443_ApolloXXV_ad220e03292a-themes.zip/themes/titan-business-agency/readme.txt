=== Titan Business Agency ===
Contributors: titanthemes
Requires at least: 6.1
Tested up to: 6.7
Requires PHP: 7.2
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Titan Business Agency WordPress Theme is a versatile and dynamic solution designed for agencies offering a range of services like business consulting, digital marketing, web development, SEO, and more. Perfect for agencies of all sizes, including branding, advertising, and creative agencies, this theme allows you to showcase your expertise in business strategy, business development, and digital solutions with a professional online presence. The theme is ideal for agencies providing business coaching, market research, business analytics, or financial services. Its clean, modern design and intuitive layout help convey professionalism and attract clients across industries. With flexible customization options, the Titan Business Agency WordPress Theme enables you to tailor your site to reflect your agency's unique identity and services. The theme also integrates well with essential tools and plugins for lead generation, client management, and project showcase, making it perfect for agencies focused on business growth, innovation, and transformation. This theme also offers an array of pre-built sections for presenting case studies, services, client testimonials, and team members, along with a powerful contact form for seamless communication. Whether you're a startup agency or a large corporate agency, this theme provides the right tools to scale your business, improve your digital marketing, and enhance client relationships.

== Changelog ==

= 1.0 =
* Released: December 06, 2024

= 1.1 =
* Added footer link: Dec 23, 2024
* Added getstarted: Dec 23, 2024
* Updated Pot file: Dec 23, 2024

= 1.2 =
* Added blog grid layout template : JAN 07, 2025
* Added front-page template : JAN 07, 2025
* Added CSS for grid layout : JAN 07, 2025
* Updated home.html file : JAN 07, 2025

== Copyright ==

Titan Business Agency WordPress Theme, (C) 2022-2024 Titan Themes
Titan Business Agency is distributed under the terms of the GNU GPL.

Titan Business Agency WordPress Theme incorporates code from Twenty Twenty-Three WordPress Theme, Copyright 2022-2024 WordPress.org
Twenty Twenty-Three WordPress Theme is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1629588

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/946516

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1573331

Google Web Fonts ( Allura, Fira+Sans, Inter, Oswald, Roboto+Flex, Nunito) By Google - https://google.com

* Allura, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Allura?query=Allura

* Fira+Sans, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Fira+Sans?query=Fira+Sans

* Inter, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Inter?query=Inter

* Oswald, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Oswald?query=Oswald

* Roboto+Flex, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Roboto+Flex?query=+Roboto+Flex

* Nunito, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Nunito?query=Nunito