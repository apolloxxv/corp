<?php 

function openmind_theme_custom_script(){

    wp_enqueue_script( 'custom-js', get_template_directory_uri() . '/assets/js/custom.js', array(), array(), true );
}

add_action( 'wp_enqueue_scripts', 'openmind_theme_custom_script' );

// Add block patterns
require get_stylesheet_directory() . '/inc/block-patterns.php';

// Add Customizer
require get_stylesheet_directory() . '/inc/customizer.php';


// Upsell in the customizer
if ( class_exists( 'WP_Customize_Section' ) ) {
	class openmind_Upsell_Section extends WP_Customize_Section {
		public $type = 'openmind-upsell';
		public $button_text = '';
		public $url = '';
		public $background = '';
		public $text_color = '';
		protected function render() {
			$background = ! empty( $this->background ) ? esc_attr( $this->background ) : 'linear-gradient(90deg,rgb(0,0,0) 0%,rgb(0,0,0) 35%,rgb(0,0,0) 70%,rgb(0,0,0) 100%)
            ';
			$text_color       = ! empty( $this->text_color ) ? esc_attr( $this->text_color ) : '#fff';
			?>
			<li id="accordion-section-<?php echo esc_attr( $this->id ); ?>" class="openmind_upsell_section accordion-section control-section control-section-<?php echo esc_attr( $this->id ); ?> cannot-expand">
				<h3 class="accordion-section-title" style="border: 0; color:#fff; background:<?php echo esc_attr( $background ); ?>;">
					<?php echo esc_html( $this->title ); ?>
					<a href="<?php echo esc_url( $this->url ); ?>" class="button button-secondary alignright" target="_blank" style="margin-top: -4px;"><?php echo esc_html( $this->button_text ); ?></a>
				</h3>
			</li>
			<?php
		}
	}
}


// Add Get Started
require get_stylesheet_directory() . '/inc/get-started/get-started.php';


/* Theme credit link */
define('openmind_BUY_NOW',__('https://hangoutthemes.com/theme-openmind','openmind'));
define('openmind_PRO_DEMO',__('https://preview.hangoutthemes.com/openmind/','openmind'));
define('openmind_REVIEW',__('https://hangoutthemes.com/theme-openmind','openmind'));
define('openmind_SUPPORT',__('https://hangoutthemes.com/','openmind'));
?>