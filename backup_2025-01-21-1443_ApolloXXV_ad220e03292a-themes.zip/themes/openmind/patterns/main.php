<?php
/**
 * Title: main
 * Slug: openmind/main
 * Categories: 
 */
?>
<!-- wp:group {"tagName":"main","metadata":{"name":"Main"},"style":{"spacing":{"padding":{"top":"0","bottom":"0"}},"dimensions":{"minHeight":"85vh"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch","verticalAlignment":"top"}} -->
<main class="wp-block-group" style="min-height:85vh;padding-top:0;padding-bottom:0">

<!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:group {"metadata":{"name":"light-darkblue"},"className":"light-darkblue","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-darkblue"></div>
<!-- /wp:group -->

<!-- wp:group {"className":"w100","style":{"dimensions":{"minHeight":"100%"},"layout":{"selfStretch":"fill","flexSize":null},"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center","justifyContent":"center"}} -->
<div class="wp-block-group w100" style="min-height:100%;padding-right:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"className":"break-reverse w100","style":{"spacing":{"blockGap":"var:preset|spacing|80"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"bottom","justifyContent":"center"}} -->
<div class="wp-block-group break-reverse w100"><!-- wp:group {"className":"fade-up","style":{"spacing":{"blockGap":"var:preset|spacing|30"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group fade-up"><!-- wp:heading {"textAlign":"center","level":1,"className":"light-show","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"white","fontSize":"x-large"} -->
<h1 class="wp-block-heading has-text-align-center light-show has-white-color has-text-color has-link-color has-x-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( 'Open your mind to the new', 'openmind' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></main>
<!-- /wp:group -->