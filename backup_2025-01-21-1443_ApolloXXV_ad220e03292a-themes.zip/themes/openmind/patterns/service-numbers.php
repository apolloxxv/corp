<?php
/**
 * Title: service-numbers
 * Slug: openmind/service-numbers
 * Categories: 
 */
?>
<!-- wp:group {"metadata":{"name":"Service numbers"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"},"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--80);margin-bottom:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"break-row","style":{"spacing":{"blockGap":"var:preset|spacing|50"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"stretch","justifyContent":"center"}} -->
<div class="wp-block-group break-row"><!-- wp:group {"className":"break-row","style":{"layout":{"selfStretch":"fixed","flexSize":"50%"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60","right":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|80"}},"backgroundColor":"custom-color-9","layout":{"type":"flex","orientation":"horizontal","justifyContent":"left","verticalAlignment":"top","flexWrap":"nowrap"}} -->
<div class="wp-block-group break-row has-custom-color-9-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"white","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-left fade-up has-white-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( 'Our services will help you get online and increase your sales', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-left fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.Lorem ipsum odor amet, consectetuer adipiscing elit. Risus lacus a urna ultrices consequat massa tempus. Sollicitudin tellus condimentum penatibus tempus himenaeos rutrum potenti. Lacus mus commodo semper sit magna. Atortor sapien aptent luctus porta convallis aliquam. Gravida semper ullamcorper blandit mollis mi dolor curabitur volutpat. Varius euismod aliquam conubia; ultrices suscipit egestas. Accumsan sollicitudin aliquam fames lectus himenaeos nunc. Tempus curabitur lacinia volutpat porta ultricies. Massa sociosqu accumsan quam ultricies morbi luctus elementum.', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img52-683x1024.jpg","dimRatio":50,"focalPoint":{"x":0.5,"y":0.66000000000000003},"contentPosition":"bottom center","style":{"color":[]}} -->
<div class="wp-block-cover has-custom-content-position is-position-bottom-center"><span aria-hidden="true" class="wp-block-cover__background has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img52-683x1024.jpg" style="object-position:50% 66%" data-object-fit="cover" data-object-position="50% 66%"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"flex","orientation":"horizontal","verticalAlignment":"top","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","className":"fade-up counter","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-3"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"custom-color-3","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-center fade-up counter has-custom-color-3-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( '505K', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Monthly visitors', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","className":"fade-up counter","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-3"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"custom-color-3","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-center fade-up counter has-custom-color-3-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( '98K', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Positive feedback', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","className":"fade-up counter","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-3"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"custom-color-3","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-center fade-up counter has-custom-color-3-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( '165M', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Products sold', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->