<?php
/**
 * Title: start-now
 * Slug: openmind/start-now
 * Categories: 
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img-45.jpg","hasParallax":true,"dimRatio":0,"customOverlayColor":"#634c40","metadata":{"name":"Start now"},"style":{"color":{"duotone":"unset"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover has-parallax"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#634c40"></span><div class="wp-block-cover__image-background has-parallax" style="background-position:50% 50%;background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img-45.jpg)"></div><div class="wp-block-cover__inner-container"><!-- wp:group {"metadata":{"name":"Creative"},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","align":"full","style":{"typography":{"textTransform":"lowercase","lineHeight":"0.9"},"elements":{"link":{"color":{"text":"#ffffff45"}}},"color":{"text":"#ffffff45"}},"fontSize":"super"} -->
<h2 class="wp-block-heading alignfull has-text-align-center has-text-color has-link-color has-super-font-size" style="color:#ffffff45;line-height:0.9;text-transform:lowercase"><?php echo esc_html_e( 'start now', 'openmind' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->