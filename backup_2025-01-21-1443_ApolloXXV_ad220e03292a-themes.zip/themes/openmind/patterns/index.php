<?php
/**
 * Title: index
 * Slug: openmind/index
 * Inserter: no
 */
?>
<!-- wp:group {"style":{"background":{"backgroundImage":{"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/lines-2.png","id":107,"source":"file","title":"lines-2"},"backgroundSize":"contain"},"spacing":{"margin":{"top":"0"}}},"backgroundColor":"custom-color-1","layout":{"type":"default"}} -->
<div class="wp-block-group has-custom-color-1-background-color has-background" style="margin-top:0"><!-- wp:group {"metadata":{"name":"Main"},"style":{"spacing":{"padding":{"top":"0","bottom":"0"}},"dimensions":{"minHeight":"85vh"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch","verticalAlignment":"top"}} -->
<div class="wp-block-group" style="min-height:85vh;padding-top:0;padding-bottom:0"><!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:group {"metadata":{"name":"light-darkblue"},"className":"light-darkblue","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-darkblue"></div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"main","className":"w100","style":{"dimensions":{"minHeight":"100%"},"layout":{"selfStretch":"fill","flexSize":null},"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center","justifyContent":"center"}} -->
<main class="wp-block-group w100" style="min-height:100%;padding-right:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"className":"break-reverse w100","style":{"spacing":{"blockGap":"var:preset|spacing|80"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"bottom","justifyContent":"center"}} -->
<div class="wp-block-group break-reverse w100"><!-- wp:group {"className":"fade-up","style":{"spacing":{"blockGap":"var:preset|spacing|30"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group fade-up"><!-- wp:heading {"textAlign":"center","level":1,"className":"light-show","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"white","fontSize":"x-large"} -->
<h1 class="wp-block-heading has-text-align-center light-show has-white-color has-text-color has-link-color has-x-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( 'Open your mind to the new', 'openmind' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></main>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"light-blue"},"className":"light-blue right","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-blue right"></div>
<!-- /wp:group -->

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img-45.jpg","hasParallax":true,"dimRatio":0,"customOverlayColor":"#634c40","metadata":{"name":"Start now"},"style":{"color":{"duotone":"unset"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover has-parallax"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#634c40"></span><div class="wp-block-cover__image-background has-parallax" style="background-position:50% 50%;background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img-45.jpg)"></div><div class="wp-block-cover__inner-container"><!-- wp:group {"metadata":{"name":"Creative"},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","align":"full","style":{"typography":{"textTransform":"lowercase","lineHeight":"0.9"},"elements":{"link":{"color":{"text":"#ffffff45"}}},"color":{"text":"#ffffff45"}},"fontSize":"super"} -->
<h2 class="wp-block-heading alignfull has-text-align-center has-text-color has-link-color has-super-font-size" style="color:#ffffff45;line-height:0.9;text-transform:lowercase"><?php echo esc_html_e( 'start now', 'openmind' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"metadata":{"name":"Service numbers"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"},"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--80);margin-bottom:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"break-row","style":{"spacing":{"blockGap":"var:preset|spacing|50"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"stretch","justifyContent":"center"}} -->
<div class="wp-block-group break-row"><!-- wp:group {"className":"break-row","style":{"layout":{"selfStretch":"fixed","flexSize":"50%"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60","right":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|80"}},"backgroundColor":"custom-color-9","layout":{"type":"flex","orientation":"horizontal","justifyContent":"left","verticalAlignment":"top","flexWrap":"nowrap"}} -->
<div class="wp-block-group break-row has-custom-color-9-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"white","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-left fade-up has-white-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( 'Our services will help you get online and increase your sales', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-left fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.Lorem ipsum odor amet, consectetuer adipiscing elit. Risus lacus a urna ultrices consequat massa tempus. Sollicitudin tellus condimentum penatibus tempus himenaeos rutrum potenti. Lacus mus commodo semper sit magna. Atortor sapien aptent luctus porta convallis aliquam. Gravida semper ullamcorper blandit mollis mi dolor curabitur volutpat. Varius euismod aliquam conubia; ultrices suscipit egestas. Accumsan sollicitudin aliquam fames lectus himenaeos nunc. Tempus curabitur lacinia volutpat porta ultricies. Massa sociosqu accumsan quam ultricies morbi luctus elementum', 'openmind' ); ?>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img52-683x1024.jpg","dimRatio":50,"focalPoint":{"x":0.5,"y":0.66000000000000003},"contentPosition":"bottom center","style":{"color":[]}} -->
<div class="wp-block-cover has-custom-content-position is-position-bottom-center"><span aria-hidden="true" class="wp-block-cover__background has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/img52-683x1024.jpg" style="object-position:50% 66%" data-object-fit="cover" data-object-position="50% 66%"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"flex","orientation":"horizontal","verticalAlignment":"top","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","className":"fade-up counter","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-3"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"custom-color-3","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-center fade-up counter has-custom-color-3-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( '505K', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Monthly visitors', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","className":"fade-up counter","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-3"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"custom-color-3","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-center fade-up counter has-custom-color-3-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( '98K', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Positive feedback', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","className":"fade-up counter","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-3"}}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"textColor":"custom-color-3","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-center fade-up counter has-custom-color-3-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:500"><?php echo esc_html_e( '165M', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Products sold', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"light-blue"},"className":"light-blue","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group light-blue"></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Integrations"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"},"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--80);margin-bottom:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"style":{"layout":{"selfStretch":"fixed","flexSize":"30%"},"spacing":{"blockGap":"0"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"large"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-large-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Exclusive integrations', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","className":"fade-up","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}},"layout":{"selfStretch":"fit","flexSize":null}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center fade-up has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"light-darkblue"},"className":"light-darkblue right","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-darkblue right"></div>
<!-- /wp:group -->

<!-- wp:group {"className":"fade-up break-row","style":{"layout":{"selfStretch":"fit","flexSize":null},"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|80"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center","verticalAlignment":"center"}} -->
<div class="wp-block-group fade-up break-row" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"up-down","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group up-down"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"50%"},"color":{"background":"#e6007e61"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:50%;background-color:#e6007e61;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","size":"has-huge-icon-size","className":"is-style-logos-only","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":{"top":"0"}}}} -->
<ul class="wp-block-social-links has-huge-icon-size has-icon-color is-style-logos-only" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0"><!-- wp:social-link {"url":"#","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"medium"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-medium-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Instagram', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"border":{"radius":"20px"},"color":{"background":"#ffffff30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:20px;background-color:#ffffff30;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-small-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Social media', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"up-down","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group up-down"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"50%"},"color":{"background":"#0792e369"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:50%;background-color:#0792e369;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","size":"has-large-icon-size","className":"is-style-logos-only","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":{"top":"0"}}}} -->
<ul class="wp-block-social-links has-large-icon-size has-icon-color is-style-logos-only" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0"><!-- wp:social-link {"url":"#","service":"facebook"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"medium"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-medium-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Facebook', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"border":{"radius":"20px"},"color":{"background":"#ffffff30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:20px;background-color:#ffffff30;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-small-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'SEO', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"up-down","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group up-down"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"50%"},"color":{"background":"#5214ff47"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:50%;background-color:#5214ff47;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","size":"has-large-icon-size","className":"is-style-logos-only","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":{"top":"0"}}}} -->
<ul class="wp-block-social-links has-large-icon-size has-icon-color is-style-logos-only" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0"><!-- wp:social-link {"url":"#","service":"behance"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"medium"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-medium-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Behance', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"border":{"radius":"20px"},"color":{"background":"#ffffff30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:20px;background-color:#ffffff30;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-small-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Share portfolio', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"up-down","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group up-down"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"50%"},"color":{"background":"#00d1656b"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:50%;background-color:#00d1656b;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","size":"has-huge-icon-size","className":"is-style-logos-only","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":{"top":"0"}}}} -->
<ul class="wp-block-social-links has-huge-icon-size has-icon-color is-style-logos-only" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0"><!-- wp:social-link {"url":"#","service":"whatsapp"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"medium"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-medium-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Whatsapp', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"border":{"radius":"20px"},"color":{"background":"#ffffff30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:20px;background-color:#ffffff30;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"lineHeight":"1.5","textTransform":"none"}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-small-font-size" style="line-height:1.5;text-transform:none"><?php echo esc_html_e( 'Chatbot', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Contact"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--40)"><!-- wp:group {"className":"break-row fade-up","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|70","right":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|50"},"border":{"width":"0px","style":"none"}},"backgroundColor":"custom-color-9","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"stretch","justifyContent":"space-between"}} -->
<div class="wp-block-group break-row fade-up has-custom-color-9-background-color has-background" style="border-style:none;border-width:0px;padding-top:0;padding-right:var(--wp--preset--spacing--70);padding-bottom:0;padding-left:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"w100","style":{"layout":{"selfStretch":"fixed","flexSize":"60%"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group w100" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"textAlign":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"600"}},"textColor":"white","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-left has-white-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:600"><?php echo esc_html_e( 'Interested? Come talk to us!', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-left has-white-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Ullamcorper malesuada proin libero nunc consequat interdum. Malesuada bibendum arcu vitae elementum curabitur vitae.', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons"><!-- wp:button {"textAlign":"center","textColor":"white","gradient":"blue-dark-to-blue-light","className":"btn-invert btn-contact","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"left":"var:preset|spacing|70","right":"var:preset|spacing|70","top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}},"border":{"width":"2px"}},"borderColor":"custom-color-1"} -->
<div class="wp-block-button btn-invert btn-contact"><a class="wp-block-button__link has-white-color has-blue-dark-to-blue-light-gradient-background has-text-color has-background has-link-color has-border-color has-custom-color-1-border-color has-text-align-center wp-element-button" style="border-width:2px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><?php echo esc_html_e( 'Get in touch', 'openmind' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"width":"350px","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"0px"},"color":{"duotone":["#171720","#E8E8E8"]}}} -->
<figure class="wp-block-image size-large is-resized has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/silhouette-sky-sunset-skyscraper-cityscape-dusk-1362207-pxhere.com_-1024x699.jpg" alt="" style="border-radius:0px;width:350px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"light-darkblue"},"className":"light-darkblue scale2 opacity05","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-darkblue scale2 opacity05"></div>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","tagName":"footer"} /--></div>
<!-- /wp:group -->