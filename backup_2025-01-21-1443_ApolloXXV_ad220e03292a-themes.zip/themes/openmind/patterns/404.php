<?php
/**
 * Title: 404
 * Slug: openmind/404
 * Inserter: no
 */
?>
<!-- wp:group {"style":{"dimensions":{"minHeight":"100vh"},"background":{"backgroundImage":{"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/lines-2.png","id":107,"source":"file","title":"lines-2"}}},"backgroundColor":"custom-color-1","layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group has-custom-color-1-background-color has-background" style="min-height:100vh"><!-- wp:template-part {"slug":"header","area":"header","align":"full"} /-->

<!-- wp:group {"metadata":{"name":"light-blue"},"className":"light-blue right","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-blue right"></div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"main","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<main class="wp-block-group"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"xxx-large"} -->
<p class="has-text-align-center has-custom-color-6-color has-text-color has-link-color has-xxx-large-font-size"><?php echo esc_html_e( '404', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"up70","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group up70"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color has-medium-font-size"><?php echo esc_html_e( 'Oops! Page not found', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-6"}}}},"textColor":"custom-color-6","fontSize":"small"} -->
<p class="has-text-align-center has-custom-color-6-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'This page does not exist', 'openmind' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"gradient":"blue-dark-to-blue-light"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-blue-dark-to-blue-light-gradient-background has-background wp-element-button"><?php echo esc_html_e( 'Back to home 🡒', 'openmind' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></main>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"light-darkblue"},"className":"light-darkblue","layout":{"type":"constrained"}} -->
<div class="wp-block-group light-darkblue"></div>
<!-- /wp:group --></div>
<!-- /wp:group -->