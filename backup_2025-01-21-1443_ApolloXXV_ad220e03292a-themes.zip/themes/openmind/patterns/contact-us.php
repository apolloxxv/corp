<?php
/**
 * Title: contact-us
 * Slug: openmind/contact-us
 * Categories: 
 */
?>
<!-- wp:group {"metadata":{"name":"Contact"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--40)"><!-- wp:group {"className":"break-row fade-up","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|70","right":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|50"},"border":{"width":"0px","style":"none"}},"backgroundColor":"custom-color-9","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"stretch","justifyContent":"space-between"}} -->
<div class="wp-block-group break-row fade-up has-custom-color-9-background-color has-background" style="border-style:none;border-width:0px;padding-top:0;padding-right:var(--wp--preset--spacing--70);padding-bottom:0;padding-left:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"w100","style":{"layout":{"selfStretch":"fixed","flexSize":"60%"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group w100" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"textAlign":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"600"}},"textColor":"white","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-left has-white-color has-text-color has-link-color has-large-font-size" style="font-style:normal;font-weight:600"><?php echo esc_html_e( 'Interested? Come talk to us!', 'openmind' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-left has-white-color has-text-color has-link-color has-small-font-size"><?php echo esc_html_e( 'Ullamcorper malesuada proin libero nunc consequat interdum. Malesuada bibendum arcu vitae elementum curabitur vitae.', 'openmind' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons"><!-- wp:button {"textAlign":"center","textColor":"white","gradient":"blue-dark-to-blue-light","className":"btn-invert btn-contact","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"left":"var:preset|spacing|70","right":"var:preset|spacing|70","top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}},"border":{"width":"2px"}},"borderColor":"custom-color-1"} -->
<div class="wp-block-button btn-invert btn-contact"><a class="wp-block-button__link has-white-color has-blue-dark-to-blue-light-gradient-background has-text-color has-background has-link-color has-border-color has-custom-color-1-border-color has-text-align-center wp-element-button" style="border-width:2px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><?php echo esc_html_e( 'Get in touch', 'openmind' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"width":"350px","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"0px"},"color":{"duotone":["#171720","#E8E8E8"]}}} -->
<figure class="wp-block-image size-large is-resized has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/silhouette-sky-sunset-skyscraper-cityscape-dusk-1362207-pxhere.com_-1024x699.jpg" alt="" style="border-radius:0px;width:350px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->