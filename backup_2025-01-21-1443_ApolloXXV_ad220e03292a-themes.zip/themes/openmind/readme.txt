== openmind ==

Contributors: 
Requires at least: 6.6
Tested up to: 6.6
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Openmind is a versatile and visually stunning WordPress theme designed for creative professionals. With its unique and dynamic design, Openmind lets you push the boundaries of business design. The theme offers a highly customizable layout perfect for portfolios, with smooth navigation and an emphasis on creativity. Ideal for personal or professional use, Openmind gives you the tools to showcase your talent and captivate your audience effortlessly.

== Changelog ==

= 1.0.0 =
* Initial release

== Resources ==

Google Web Fonts (Outfit) by Google - https://google.com

Outfit: This Font Software is licensed under the SIL Open Font License, Version 1.1 (https://openfontlicense.org/open-font-license-official-text/).
Available at: https://fonts.google.com/specimen/Outfit

== Images ==
License for images:

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/

Avatars: 
https://stocksnap.io/photo/business-people-PAQJGIXNYI
https://stocksnap.io/photo/computer-laptop-UB4RZ1RKPI
https://stocksnap.io/photo/browsing-technology-WFEYZYN6V7
creative:https://stocksnap.io/photo/business-people-FRU4Y0OBEY

img31: https://pxhere.com/pt/photo/730866
img52:https://pxhere.com/pt/photo/111171
silhouette-sky-sunset-skyscraper-cityscape-dusk-1362207-pxhere.com_-1024x699:https://pxhere.com/pt/photo/1362207

== Copyright ==

Openmind WordPress Theme, (C) 2024 
Openmind is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

(C) Hangout Themes, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)
