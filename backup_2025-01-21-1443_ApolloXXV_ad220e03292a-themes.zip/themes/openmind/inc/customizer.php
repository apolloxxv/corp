<?php 

/**
 * Customizer
 * 
 * @package WordPress
 * @subpackage openmind
 * @since openmind1.0
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function openmind_customize_register( $wp_customize ) {
	$wp_customize->add_section( new openmind_Upsell_Section($wp_customize,'upsell_section',array(
		'title'            => __( 'Openmind Pro', 'openmind' ),
		'button_text'      => __( 'Upgrade Pro', 'openmind' ),
		'url'              => esc_url( openmind_BUY_NOW ),
		'priority'         => 0,
	)));
}
add_action( 'customize_register', 'openmind_customize_register' );

/**
 * Enqueue script for custom customize control.
 */
function openmind_custom_control_scripts() {
	wp_enqueue_script( 'openmind-custom-controls-js', get_template_directory_uri() . '/assets/js/custom-controls.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-sortable' ), '1.0', true );
}
add_action( 'customize_controls_enqueue_scripts', 'openmind_custom_control_scripts' );
?>