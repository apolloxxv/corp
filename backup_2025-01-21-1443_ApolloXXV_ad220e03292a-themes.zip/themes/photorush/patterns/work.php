<?php
/**
 * Title: Our Work
 * Slug: photorush/work
 * Categories: photorush, work
 */
?>

<!-- wp:group {"style":{"spacing":{"margin":{"top":"0px"},"padding":{"top":"60px","right":"20px","bottom":"60px","left":"20px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:0px;padding-top:60px;padding-right:20px;padding-bottom:60px;padding-left:20px"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"width":"2px"}},"borderColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-primary-border-color" style="border-width:2px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><!-- wp:heading {"level":4,"style":{"spacing":{"padding":{"top":"0px","bottom":"0px","left":"0px","right":"0px"}},"elements":{"link":{"color":{"text":"var:preset|color|primary"}}},"typography":{"fontStyle":"normal","fontWeight":"600","textTransform":"uppercase","letterSpacing":"0.12em"}},"textColor":"primary","fontSize":"medium"} -->
<h4 class="wp-block-heading has-primary-color has-text-color has-link-color has-medium-font-size" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;font-style:normal;font-weight:600;letter-spacing:0.12em;text-transform:uppercase"><?php esc_html_e('Projects Work','photorush'); ?></h4>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"10px"}}},"textColor":"secondary","fontSize":"section-title"} -->
<h2 class="wp-block-heading has-text-align-center has-secondary-color has-text-color has-section-title-font-size" style="margin-top:10px"><?php esc_html_e('Take A Look At My Recent Project Works','photorush'); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--30)"><?php esc_html_e('There are many variations of passages of lorem Ipsum available, but the majority have suffered alteration in some form, by injected humor, or randomized words which dont look even slightly.','photorush'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"15px"} -->
<div style="height:15px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:gallery {"linkTo":"none"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-cropped"><!-- wp:image {"lightbox":{"enabled":true},"id":174,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"5px"}},"borderColor":"primary"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri().'/assets/img/port-1.jpg' ); ?>" alt="" class="has-border-color has-primary-border-color wp-image-174" style="border-width:5px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":true},"id":176,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"5px"}},"borderColor":"primary"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri().'/assets/img/port-2.jpg' ); ?>" alt="" class="has-border-color has-primary-border-color wp-image-176" style="border-width:5px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":true},"id":175,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"5px"}},"borderColor":"primary"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri().'/assets/img/port-3.jpg' ); ?>" alt="" class="has-border-color has-primary-border-color wp-image-175" style="border-width:5px"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->