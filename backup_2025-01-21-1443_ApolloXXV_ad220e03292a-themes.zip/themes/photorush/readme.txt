﻿=== Photorush ===

Contributors: Alexathemes
Requires at least: 6.1
Tested up to: 6.6
Requires PHP: 7.0
Stable tag: 1.0.1
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
Tags: photography, blog, e-commerce, one-column, custom-colors, custom-menu, custom-logo, editor-style, featured-images, full-site-editing, block-patterns, rtl-language-support, sticky-post, threaded-comments, right-sidebar

== Description ==

Photorush is a Full Site Editing Photography WordPress Theme, meticulously crafted for photographers and photobloggers who want to showcase their work in a visually captivating and professional manner. This theme is the perfect solution for anyone passionate about photography, offering a stunning platform to display your portfolio, share your creative journey, and even sell your photos online. With a design that prioritizes image quality and storytelling, this theme is built to help you make a lasting impression on your audience. The responsive layout ensures that your photos look incredible on any device, whether it's a desktop, tablet, or smartphone, making it easy for your visitors to enjoy your work no matter where they are. In today's competitive digital landscape, SEO-friendliness is essential, and this theme has been optimized to help you rank higher on search engines, ensuring that your website gets the visibility it deserves. Whether you're sharing your latest shoot or writing a blog post about your photography adventures, this theme is built to attract and retain visitors. Additionally, this Photography WordPress Theme is WooCommerce compatible, allowing you to effortlessly set up an online store and sell your photography services, prints, or digital downloads directly from your website. This seamless integration ensures a smooth shopping experience for your customers, all while maintaining the visual integrity of your site. The theme is fully tested with the latest WordPress versions, ensuring compatibility and smooth performance across all updates. This means you can focus on your creativity without worrying about technical glitches or outdated features. The Full Site Editing capabilities allow you to easily customize every aspect of your site, from headers to footers, without touching a single line of code. You can create a unique look that matches your personal style or brand, giving you complete control over the design and functionality of your website. Whether you're a professional photographer looking to establish a strong online presence or a passionate photoblogger wanting to share your journey with the world, this Photography WordPress Theme offers everything you need to create a stunning, user-friendly, and fully functional website. It's more than just a theme; it's a tool that empowers you to bring your vision to life and connect with your audience in meaningful ways. Get ready to elevate your photography website to new heights with this exceptional WordPress theme.
 
== Theme Resources == 

Theme is built using the following resource bundles:		
		
1) Details of images used in Screenshot:
        
	i) Image for theme screenshot, copyrights under Creative Commons CC0
		License: CC0 1.0 Universal (CC0 1.0)
	 	https://pxhere.com/en/photo/614
	        https://pxhere.com			

2) photorush/assests
	* Fonts:
	  -  Barlow
	     	Barlow is designed by Jeremy Tribby
		License:  These fonts are licensed under the Open Font License., Version 2.0.
		https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL#3b878279
		Source: https://fonts.google.com/specimen/Barlow

	  -  Poppins
	     	Poppins is designed by Indian Type Foundry
		License:  These fonts are licensed under the Open Font License., Version 2.0.
		https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL#3b878279
		Source: https://fonts.google.com/specimen/Poppins


*   License

	 Photorush WordPress Theme, Copyright 2024 Alexathemes
	 Photorush is distributed under the terms of the GNU GPL
        
For any help you can mail us at support[at]alexathemes.net


== Photorush log ==

= 1.0 =
*      Initial version release.

= 1.0.1 =
*      Minor css changes.