<?php 
	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	} // Exit if accessed directly
?>

<div class="moove-gdpr-cookie-notice">
  <?php echo $content->text_content; ?>
</div>
<!--  .moove-gdpr-cookie-notice -->