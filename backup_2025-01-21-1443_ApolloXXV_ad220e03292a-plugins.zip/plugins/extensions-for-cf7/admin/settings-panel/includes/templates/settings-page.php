<div class="wrap htcf7ext-settings-page-wrapper">
    <?php do_action('extcf7_admin_notices') ?>
    <div id="htcf7ext-opt-admin-app"></div>
    <?php include_once HTCF7EXTOPT_INCLUDES .'/templates/sidebar-banner.php'; ?>
</div>