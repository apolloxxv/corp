<span style="float:right;margin-left:2em;margin-top:-6px;text-shadow:1px 2px 0 #fff"><strong>
<?php _e( 'New user?', 'child-theme-configurator' ); ?>
<span style="color:#F1823B">
<?php _e( 'Click help', 'child-theme-configurator' ); ?>
</span></strong> <i class="dashicons dashicons-arrow-right-alt" style="color:#F1823B"></i></span>
<div style="float:right;font-size:1rem;max-width:320px;line-height:1.2;padding:.5em;background:papayawhip;margin-top:-4px;border-radius:1rem">
    <strong><?php _e( 'Help us help you!', 'child-theme-configurator' ); ?></strong>
    <?php printf( __( 'If you find this plugin useful, please support us by %supgrading%s or %sclick here to donate as little as $1.%s', 'child-theme-configurator' ),
                 '<a href="https://www.lilaeamedia.com/product/child-theme-configurator-pro/" target="_blank" rel="noreferrer noopener">', '</a>', '<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8QE5YJ8WE96AJ" target="_blank" rel="noreferrer noopener"><strong>', '</strong></a>' ); ?>
<!-- a href="<?php echo LILAEAMEDIA_URL; ?>/product/hook-highlighter/" target="_blank" 
   title="<?php _e( 'Hook Highlighter - See It In Action', 'child-theme-configurator' ); ?>" 
   style="float:right"><img src="<?php echo CHLD_THM_CFG_URL; ?>css/hook-highlighter-button.jpg" 
                            height="54" width="240"  style="margin-top:-10px"
                            alt="<?php _e( 'Hook Highlighter - See Below The Surface', 'child-theme-configurator' ); ?>" />
</a -->
    </div>